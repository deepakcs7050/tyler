import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { GetPostRes } from "src/app/model/post/getPostResponse";

export class PostAdapter {

    constructor(private fb:FormBuilder) { }


    /** Posts  request req params */
    createPost(title: string, body: string): GetPostRes {
        console.log(title,body);
        
        let post = {} as GetPostRes;
        post.title = title
        post.body = body
        return post;
    }


    oreatePostForm(): FormGroup {
        return this.fb.group({
        title: ['', Validators.required],
        body: ['', Validators.required],
        });
        }

}