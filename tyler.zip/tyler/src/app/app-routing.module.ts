import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CardComponent } from './component/card/card.component';
import { DeleteComponent } from './component/delete/delete.component';
import { EditPostComponent } from './component/edit-post/edit-post.component';
import { PostsListComponent } from './component/posts-list/posts-list.component';
import { ViewComponent } from './component/view/view.component';

const routes: Routes = [
  { path: 'post', component: PostsListComponent },
  { path: 'edit/id', component: EditPostComponent },
  { path: 'delete/id', component: DeleteComponent },
  { path: 'card',component: CardComponent},
  { path: 'view',component:ViewComponent},
  {
    path: '',
    redirectTo: 'post',
    pathMatch: 'full'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
