import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { GetPostRes } from '../model/post/getPostResponse';
import { Observable, throwError } from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class PostService {

  token = '1234';
  constructor(@Inject('environment') private environment: any, private http: HttpClient,) { }
  public Token = () : string => this.token;

  getPostList(): Observable<GetPostRes> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.get<GetPostRes>(`${this.environment.BaseURL}/posts`)
  }

  createNewPost(request: GetPostRes) {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.post<GetPostRes>(`${this.environment.BaseURL}/posts`,
      request,
      { headers: headers, observe: 'response' }
    ).pipe((response: any) => {
      if (response.status === 200) {
        let data = response.body;
        return (data);
      }
    });
  }

  find(id: any): Observable<GetPostRes> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.get<GetPostRes>(`${this.environment.BaseURL}/posts/${id}`)
  }

  updatePost(id: any, request: any) {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    return this.http.put(`${this.environment.BaseURL}/posts/${id}`, JSON.stringify(request)
    );
  }

  delete(id:any){
    return this.http.delete(`${this.environment.BaseURL}/posts/${id}`)
  }

  errorHandler(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = 'Error Code: ${error.status}nMessage: ${error.message}';
    }
    return throwError(errorMessage);
  }


}
