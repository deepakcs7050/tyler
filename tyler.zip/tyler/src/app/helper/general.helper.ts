export class GeneralHelper {
  constructor() { }
  keepInSession = (key: string, val: any, persist?: any): any => {
    if (persist) {
      if (typeof (localStorage) !== "undefined") {
        localStorage.setItem(key, JSON.stringify(val));
      }
    }
    else {
      if (typeof (sessionStorage) !== "undefined") {
        sessionStorage.setItem(key, JSON.stringify(val));
      }
    }
  }

  getFromSession = (key: string): any => {
    if (typeof (sessionStorage) !== "undefined") {
      let item = sessionStorage.getItem(key);
      if (item) {
        return JSON.parse(item);
      }
    }
  }


}