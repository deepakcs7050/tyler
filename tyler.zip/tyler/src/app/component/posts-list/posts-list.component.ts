import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { GeneralHelper } from 'src/app/helper/general.helper';
import { GetPostRes } from 'src/app/model/post/getPostResponse';
import { PostService } from 'src/app/services/post.service';
import { AddPostComponent } from '../add-post/add-post.component';
import { DeleteComponent } from '../delete/delete.component';
import { EditPostComponent } from '../edit-post/edit-post.component';

@Component({
  selector: 'app-posts-list',
  templateUrl: './posts-list.component.html',
  styleUrls: ['./posts-list.component.scss']
})
export class PostsListComponent implements OnInit {
  private generalHelper: GeneralHelper = new GeneralHelper()
  postList: GetPostRes | any;

  constructor(private service: PostService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.postList = this.generalHelper.getFromSession('Posts');
    if (!this.postList) {
      this.getPost();
    }
  }

  getPost() {
    this.service.getPostList().subscribe(res => {
      this.postList = res;
      console.log(this.postList);
      this.generalHelper.keepInSession('Posts', res);

    })
  }

  deleteDialog(id:number): void {
    const dialogRef = this.dialog.open(DeleteComponent, {
      height: '160px',
      width: '20%',
      data: {
        id :id
      }
    });
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(AddPostComponent, {
      height: '450px',
      width: '600px',
      data: {
      }
    });
  }

  editDialog(id:number ): void {
    const dialogRef = this.dialog.open(EditPostComponent, {
      height: '450px',
      width: '600px',
      data: {
        id :id
      }
    });
  }

}
