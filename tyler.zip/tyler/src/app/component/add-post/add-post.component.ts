import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { PostAdapter } from 'src/app/adpter/postAdapter';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.scss']
})
export class AddPostComponent implements OnInit {
  private postAdpter: PostAdapter = new PostAdapter(this.fb);
  postFormGroup: FormGroup = new FormGroup({});
  submitted = false;
  constructor(public dialog: MatDialog, private service: PostService,
    public dialogRef: MatDialogRef<AddPostComponent>, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.postFormGroup = this.postAdpter.oreatePostForm()
  }

  // convenience getter for easy access to form fields
  get f() { return this.postFormGroup.controls; }

  save() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.postFormGroup.invalid) {
      return;
    }
    const request = this.postAdpter.createPost(
      this.postFormGroup?.get('title')?.value,
      this.postFormGroup?.get('body')?.value)
    this.service.createNewPost(request).subscribe(res => {
      console.log(res);
      this.dialogRef.close();
    })

  }

  close() {
    this.dialogRef.close();
  }

}
