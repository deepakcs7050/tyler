import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {
viewDetails:any
  constructor(private service:PostService, @Inject(MAT_DIALOG_DATA) public data: any,) { }

  ngOnInit(): void {
    this.getPostDetails()
  }

  getPostDetails(){
    console.log(this.data.id);
    this.service.find(this.data.id).subscribe( res =>{
      this.viewDetails = res
    })
   }

}
