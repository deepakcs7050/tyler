import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { GeneralHelper } from 'src/app/helper/general.helper';
import { GetPostRes } from 'src/app/model/post/getPostResponse';
import { PostService } from 'src/app/services/post.service';
import { AddPostComponent } from '../add-post/add-post.component';
import { EditPostComponent } from '../edit-post/edit-post.component';
import { ViewComponent } from '../view/view.component';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  private generalHelper: GeneralHelper = new GeneralHelper()
  postList: GetPostRes | any;
  constructor(private service:PostService,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.postList = this.generalHelper.getFromSession('Posts');
    if (!this.postList) {
      this.getPost();
    }
  }

  getPost() {
    this.service.getPostList().subscribe(res => {
      this.postList = res;
      console.log(this.postList);
      this.generalHelper.keepInSession('Posts', res);

    })
  }

  viewDialog(id:number): void {
    const dialogRef = this.dialog.open(ViewComponent, {
      height: '306px',
      width: '600px',
      data: {
        id :id
      }
    });
  }

  editDialog(id:number ): void {
    const dialogRef = this.dialog.open(EditPostComponent, {
      height: '450px',
      width: '600px',
      data: {
        id :id
      }
    });
  }


}
