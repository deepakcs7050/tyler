import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PostAdapter } from 'src/app/adpter/postAdapter';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-edit-post',
  templateUrl: './edit-post.component.html',
  styleUrls: ['./edit-post.component.scss']
})
export class EditPostComponent implements OnInit {

  private postAdpter: PostAdapter = new PostAdapter(this.fb);
  postFormGroup: FormGroup = new FormGroup({});

  constructor( public dialog: MatDialog, private service:PostService,
    public dialogRef: MatDialogRef<EditPostComponent>, private fb:FormBuilder , @Inject(MAT_DIALOG_DATA) public data: any,) { }

  ngOnInit(): void {
    this.postFormGroup = this.postAdpter.oreatePostForm()
    this.getPostDetails()
  }

  getPostDetails(){
   console.log(this.data.id);
   this.service.find(this.data.id).subscribe( res =>{
     this.postFormGroup.patchValue(
       {
       title:res.title,
       body:res.body
       }
    )
   })
  }

  update(){
    if(this.postFormGroup.valid){
     console.log(this.postFormGroup?.get('title')?.value);
      const request = this.postAdpter.createPost(
        this.postFormGroup?.get('title')?.value,
        this.postFormGroup?.get('body')?.value)
      this.service.updatePost(this.data.id,request).subscribe(res =>{
      this.dialogRef.close();
      })
    }
   
  }

  close() {
    this.dialogRef.close();
  }


}
